INSERT INTO project_manager(id, name, username, password, project_name) VALUES (1, 'Deep Roy', 'dr7', 'deep1234', 'Project-1');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (2, 'Sri Harish', 'flash', 'sri1234', 'Project-2');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (3, 'Kamalesh R', 'code', 'kamalesh1234', 'Project-3');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (4, 'Megha S', 'megha', 'megha1234', 'Project-4');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (5, 'Praduman Kumar', 'eren', 'praduman1234', 'Project-5');
