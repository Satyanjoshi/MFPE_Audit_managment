package com.mfpe.service;

import java.util.List;

import com.mfpe.model.AuditBenchmark;

public interface AuditBenchmarkService {
	
	public List<AuditBenchmark> getAuditBenchmarkList();
	
}
